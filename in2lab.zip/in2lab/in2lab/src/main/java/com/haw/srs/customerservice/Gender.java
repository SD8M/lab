package com.haw.srs.customerservice;

public enum Gender {
    MALE, FEMALE, OTHER, UNKNOWN
}
